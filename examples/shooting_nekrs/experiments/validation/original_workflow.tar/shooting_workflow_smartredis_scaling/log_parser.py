#!/usr/bin/env python3
"""
Log parser module for NekRS-ML training and simulation logs.
"""

import re
from datetime import datetime
import numpy as np

def parse_timestamp(timestamp_str):
    """Parse timestamp from log line format: [2025-07-08 16:51:43,249]"""
    match = re.search(r'\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3})\]', timestamp_str)
    if match:
        timestamp = match.group(1).split(" ")[1]
        return datetime.combine(datetime.today(), datetime.strptime(timestamp, '%H:%M:%S,%f').time())
    return None

def parse_nekrs_timestamp(timestamp_str):
    """Parse NekRS timestamp from log line format: [18:12:41.544]"""
    match = re.search(r'\[(\d{2}:\d{2}:\d{2}\.\d{3})\]', timestamp_str)
    if match:
        time_str = match.group(1)
        return datetime.combine(datetime.today(), datetime.strptime(time_str, '%H:%M:%S.%f').time())
    return None

def match_nekrs_timestep(line):
    """Match NekRS timestep line and extract data."""
    # Format: [18:33:12.284] step= 8  t= 1.20625000e-01  dt=2.0e-02  C= 0.916  elapsedStep= 2.82e-02s  elapsedStepSum= 9.72314e-01s
    timestamp = parse_nekrs_timestamp(line)
    if timestamp:
        step_match = re.search(r'step=\s*(\d+).*?elapsedStep=\s*([\d\.\+e-]+)s', line)
        if step_match:
            step_num = int(step_match.group(1))
            elapsed_step = float(step_match.group(2))
            return {
                'timestamp': timestamp,
                'type': 'timestep',
                'step': step_num,
                'step_time': elapsed_step
            }
    return None

def match_nekrs_data_transport(line):
    """Match NekRS data transport line and extract data."""
    # Format: [18:33:12.341] Writing data at tstep 10 and physical time 0.160625
    if 'Writing data at tstep' in line:
        timestamp = parse_nekrs_timestamp(line)
        transport_match = re.search(r'Writing data at tstep (\d+) and physical time ([\d\.\+e-]+)', line)
        if timestamp and transport_match:
            tstep = int(transport_match.group(1))
            phys_time = float(transport_match.group(2))
            return {
                'timestamp': timestamp,
                'type': 'data_transport',
                'tstep': tstep,
                'phys_time': phys_time
            }
    return None

def match_training_timestep(line):
    """Match training timestep line and extract data."""
    # Format: [2025-07-08 16:52:41,804] - [STEP 74] loss=1.2561e+01 ... t_step=0.04833sec
    timestamp = parse_timestamp(line)
    if timestamp:
        step_match = re.search(r'\[STEP (\d+)\].*?loss=([\d\.\+e-]+).*?t_step=([\d\.]+)sec', line)
        if step_match:
            step_num = int(step_match.group(1))
            loss = float(step_match.group(2))
            step_time = float(step_match.group(3))
            return {
                'timestamp': timestamp,
                'type': 'timestep',
                'step': step_num,
                'loss': loss,
                'step_time': step_time
            }
    return None

def match_training_data_transport(line):
    """Match training data transport line and extract data."""
    # Format: [2025-07-08 18:33:59,869][client][INFO] - Getting array of size 4 bytes
    if 'Getting array of size' in line:
        timestamp = parse_timestamp(line)
        size_match = re.search(r'Getting array of size (\d+) bytes', line)
        if timestamp and size_match:
            size_bytes = int(size_match.group(1))
            size_mb = size_bytes / (1024 * 1024)
            return {
                'timestamp': timestamp,
                'type': 'data_transport',
                'size_bytes': size_bytes,
                'size_mb': size_mb
            }
    return None

def match_inference_timestep(line):
    """Match inference timestep line and extract data."""
    # Format: [2025-07-08 16:52:41,804] - [STEP 74] loss=1.2561e+01 ... t_step=0.04833sec
    timestamp = parse_timestamp(line)
    if timestamp:
        step_match = re.search(r'\[STEP (\d+)\].*?t_step=([\d\.]+)sec', line)
        if step_match:
            step_num = int(step_match.group(1))
            step_time = float(step_match.group(2))
            return {
                'timestamp': timestamp,
                'type': 'timestep',
                'step': step_num,
                'step_time': step_time
            }
    return None

def parse_log_file(file_path, matchers):
    """Generic function to parse log file using provided matcher functions."""
    events = []
    
    try:
        with open(file_path, 'r') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                
                # Try each matcher function
                for matcher in matchers:
                    event = matcher(line)
                    if event:
                        event['line'] = line_num
                        events.append(event)
                        break  # Stop after first match
                        
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return []
    
    return events

def parse_nekrs_log(file_path):
    """Parse NekRS log file and extract all events."""
    matchers = [match_nekrs_timestep, match_nekrs_data_transport]
    return parse_log_file(file_path, matchers)

def parse_training_log(file_path):
    """Parse training log file and extract all events."""
    matchers = [match_training_timestep, match_training_data_transport]
    return parse_log_file(file_path, matchers)

def parse_inference_log(file_path):
    """Parse inference log file (infer_0.out) using the same pattern as training logs."""
    # The inference log format is assumed to be identical to the training log
    return parse_log_file(file_path, [match_inference_timestep])

def calculate_mean_iteration_time(timesteps):
    """Calculate mean time between consecutive timesteps."""
    if len(timesteps) < 2:
        return 0.0
    
    # Sort by step number to ensure correct order
    timesteps.sort(key=lambda x: x['step'])
    
    # Calculate time differences between consecutive steps
    time_diffs = []
    for i in range(1, len(timesteps)):
        time_diff = (timesteps[i]['timestamp'] - timesteps[i-1]['timestamp']).total_seconds()
        time_diffs.append(time_diff)
    print(f"Time differences between timesteps: {time_diffs}")
    
    return (np.mean(time_diffs), np.std(time_diffs)) if time_diffs else 0.0

def get_init_time(file_path, parse_function):
    """Calculate initialization time (time between start time and first timestep)."""
    try:
        events = parse_function(file_path)
        if not events:
            return None
        events.sort(key=lambda x: x['timestamp'])
        if "train" not in file_path:
            # Sort events by timestamp

            with open(file_path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    first_timestamp = parse_timestamp(line)
                    if first_timestamp:
                        break
            first_data_read_time = first_timestamp
        else:

            with open(file_path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    first_timestamp = parse_timestamp(line)
                    if first_timestamp:
                        break
            first_data_read_time = get_training_first_data_read_time(file_path)
                    
        first_timestep = None
        
        for event in events:
            if event['type'] == 'timestep':
                first_timestep = event['timestamp']
                break
        
        if first_timestep:
            init_time = ((first_data_read_time - first_timestamp).total_seconds(), (first_timestep - first_data_read_time).total_seconds())
            return init_time
        else:
            return None
            
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return None

def get_training_first_data_read_time(file_path):
    """Extract training start time from training log."""
    with open(file_path, 'r') as f:
        for line in f:
            if "Found 1 trajectory files in DB" in line:
                timestamp = parse_timestamp(line)
                if timestamp:
                    return timestamp
    return None

def get_training_init_time(file_path):
    """Extract initialization time from training log."""
    return get_init_time(file_path, parse_training_log)

def get_inference_init_time(file_path):
    return get_init_time(file_path, parse_inference_log)

def get_nekrs_init_time(file_path):
    """Extract initialization time from NekRS log."""
    try:
        with open(file_path, 'r') as f:
            for line in f:
                if "initialization took" in line:
                    match = re.search(r'initialization took (\d+\.\d+) s', line)
                    if match:
                        nekrs_init = float(match.group(1))
        events = parse_nekrs_log(file_path)
        tsteps = [e for e in events if e['type'] == 'timestep']
        transport = [e for e in events if e['type'] == 'data_transport']
        print(f"Found {len(tsteps)} timesteps and {len(transport)} data transport events in NekRS log")
        if transport[0]['timestamp'] < tsteps[0]['timestamp']:
            nekrs_init += (tsteps[0]['timestamp'] - transport[0]['timestamp']).total_seconds()
        return nekrs_init
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return None
