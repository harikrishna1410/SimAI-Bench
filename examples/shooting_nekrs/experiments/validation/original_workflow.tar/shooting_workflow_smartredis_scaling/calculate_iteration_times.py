#!/usr/bin/env python3
"""
Calculate mean iteration times from log files and update runtimes.json
"""

import json
import os
import glob
from log_parser import *

def compute_mean_and_init_time(dirs, subdir, log_name, parse_log_fn, get_init_time_fn, i, data, mean_key, init_key, label):
    mean_time = 0.0
    count = 0
    print(f"\nProcessing {label} logs in directories: {dirs}")
    for d in dirs[:1]:
        log_path = os.path.join(d, subdir, log_name)
        if os.path.exists(log_path):
            print(f"Processing {label} log: {log_path}")
            events = parse_log_fn(log_path)
            
            timesteps = [e for e in events if e['type'] == 'timestep']
            
            if timesteps:
                mean_time, std_time = calculate_mean_iteration_time(timesteps)
                count += 1
                print(f"  {label} mean iteration time: {mean_time:.6f} seconds ({len(timesteps)} timesteps)")
            else:
                print(f"  No timesteps found in {label} log")
            init_time = get_init_time_fn(log_path)
            if init_time is not None:
                data[init_key][i] = init_time
                print(f"  {label} initialization time: {init_time} seconds")
            else:
                print(f"  No initialization time found in {label} log")
        else:
            print(f"{label} log not found: {log_path}")
    if count > 0:
        mean_time /= count
    data[mean_key][i] = mean_time
    data[f"{mean_key}_std"][i] = std_time if count > 0 else 0.0

def count_number_of_events(filename,parsing_fn):
    """Count the number of events in a log file."""
    events = parsing_fn(filename)
    if not events:
        return 0
    num_time_steps = sum(1 for e in events if e['type'] == 'timestep')
    num_data_transports = sum(1 for e in events if e['type'] == 'data_transport')
    print(f"Number of timesteps: {num_time_steps}, Number of data transports: {num_data_transports}")
    return (num_time_steps,num_data_transports)

def update_runtimes_json():
    """Update the runtimes.json file with calculated iteration times."""
    
    # Load existing runtimes.json
    try:
        with open('runtimes.json', 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        data = {'nodes': [2],  # Default nodes if not found
                'nekrs_iteration_time': [],
                'train_iteration_time': [],
                "inference_iteration_time": [],
                'nekrs_init_time': [],
                'train_init_time': [],
                'inference_init_time': [],
                "num_timesteps": [],
                "num_data_transports": []}
    
    nodes = data['nodes']
    
    # Initialize arrays
    data['nekrs_iteration_time'] = [0] * len(nodes)
    data['nekrs_iteration_time_std'] = [0] * len(nodes)
    data['train_iteration_time'] = [0] * len(nodes)
    data['train_iteration_time_std'] = [0] * len(nodes)
    data['inference_iteration_time'] = [0] * len(nodes)
    data['inference_iteration_time_std'] = [0] * len(nodes)
    data['nekrs_init_time'] = [0] * len(nodes)
    data['train_init_time'] = [0] * len(nodes)
    data['inference_init_time'] = [0] * len(nodes)
    data['nekrs_num_timesteps'] = [0] * len(nodes)
    data['nekrs_num_data_transports'] = [0] * len(nodes)
    data["train_num_timesteps"] = [0] * len(nodes)
    data["train_num_data_transports"] = [0] * len(nodes)
    data["inference_num_timesteps"] = [0] * len(nodes)
    data["inference_num_data_transports"] = [0] * len(nodes)

    # Process each node configuration
    for i, node_count in enumerate(nodes):
        node_dir = f"{node_count}node"
        dirs = glob.glob(os.path.join(node_dir, "nekRS-ML*"))
        compute_mean_and_init_time(
            dirs, "nekrs_0", "nekrs_0.out",
            parse_nekrs_log, get_nekrs_init_time, i, data,
            'nekrs_iteration_time', 'nekrs_init_time', 'NekRS')
        compute_mean_and_init_time(
            dirs, "train_0", "train_0.out",
            parse_training_log, get_training_init_time, i, data,
            'train_iteration_time', 'train_init_time', 'Training')
        compute_mean_and_init_time(
            dirs, "infer_0", "infer_0.out",
            parse_inference_log, get_inference_init_time, i, data,
            'inference_iteration_time', 'inference_init_time', 'Inference')
        # Count number of events
        nekrs_log_path = os.path.join(node_dir,"nekRS-ML", "nekrs_0", "nekrs_0.out")
        train_log_path = os.path.join(node_dir,"nekRS-ML", "train_0", "train_0.out")
        infer_log_path = os.path.join(node_dir,"nekRS-ML", "infer_0", "infer_0.out")
        
        num_timesteps, num_data_transports = count_number_of_events(nekrs_log_path, parse_nekrs_log)
        data['nekrs_num_timesteps'][i] += num_timesteps
        data['nekrs_num_data_transports'][i] += num_data_transports
        
        num_timesteps, num_data_transports = count_number_of_events(train_log_path, parse_training_log)
        data['train_num_timesteps'][i] += num_timesteps
        data['train_num_data_transports'][i] += num_data_transports
        
        num_timesteps, num_data_transports = count_number_of_events(infer_log_path, parse_inference_log)
        data['inference_num_timesteps'][i] += num_timesteps
        data['inference_num_data_transports'][i] += num_data_transports
    # Save updated runtimes.json
    with open('runtimes.json', 'w') as f:
        json.dump(data, f, indent=4)
    
    print("\nUpdated runtimes.json with iteration and initialization times")
    print(f"NekRS iteration times: {data['nekrs_iteration_time']}")
    print(f"Training iteration times: {data['train_iteration_time']}")
    print(f"Inference iteration times: {data['inference_iteration_time']}")
    print(f"NekRS initialization times: {data['nekrs_init_time']}")
    print(f"Training initialization times: {data['train_init_time']}")
    print(f"Inference initialization times: {data['inference_init_time']}")

if __name__ == '__main__':
    update_runtimes_json()
