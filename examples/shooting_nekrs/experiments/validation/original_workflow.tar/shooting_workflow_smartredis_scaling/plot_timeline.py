#!/usr/bin/env python3
"""
Timeline plotting script for NekRS and training log files.
Automatically finds and plots nekrs_0.out and train_0.out files.
"""

import os
import argparse
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from datetime import datetime
from log_parser import parse_nekrs_log, parse_training_log, parse_inference_log
from log_parser import parse_timestamp, parse_nekrs_timestamp
import scienceplots
# Use scienceplots for better aesthetics
plt.style.use(['science','no-latex'])

# Set matplotlib rcParams for larger fonts
plt.rcParams.update({
    'font.size': 8,
    'axes.titlesize': 8,
    'axes.labelsize': 8,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'legend.fontsize': 8,
    'figure.titlesize': 8
})

def find_log_files(root):
    """Find nekrs_0.out and train_0.out files in the directory structure."""
    log_files = {}

    files = ['nekRS-ML/nekrs_0/nekrs_0.out', 'nekRS-ML/train_0/train_0.out']#, 'nekRS-ML/infer_0/infer_0.out']
    labels = ['Simulation', 'Training']#, 'Inference']
    for label, file in zip(labels, files):
        full_path = os.path.join(root, file)
        if os.path.exists(full_path):
            log_files[label] = full_path

    return log_files

def plot_timelines(events_dict, init_timestamps, labels=None, output=None):
    colors = ['tab:blue', 'tab:orange', 'tab:green', 'tab:red', 'tab:purple']
    fig, ax = plt.subplots(figsize=(3.5, 1))

    start_time = events_dict["Simulation"]['timestep'][0]['timestamp'] if "Simulation" in events_dict else None
    for idx, (label, events) in enumerate(events_dict.items()):
        if not events:
            print(f"No events found in {label} log")
            continue
            
        tstep_events = events['timestep']
        dt_events = events['data_transport']
        tstep_times = [(e['timestamp']-start_time).total_seconds() for e in tstep_events]
        tstep_durations = [e['step_time'] for e in tstep_events]
        dt_times = [(e['timestamp']-start_time).total_seconds() for e in dt_events]
        if label in init_timestamps:
            init_timestamp = init_timestamps[label]
            init_time = (init_timestamp -  start_time).total_seconds() if init_timestamp > start_time else 0
            init_duration = tstep_times[0] - init_time

        print(f"Tstep times for {label}: {tstep_times}")
        # Plot timesteps as horizontal bars
        ax.barh(idx, tstep_durations, left=tstep_times, height=0.4, 
               color=colors[idx%len(colors)], alpha=0.7, 
               label=f"{label} Timesteps")
        
        if dt_events:
            ax.barh(idx, 0.0005, left=[t for t in dt_times if t > tstep_times[0]], height=0.4, 
                    color='red', alpha=0.9, edgecolor='darkred', linewidth=1)
        
        if label in init_timestamps:
            ax.barh(idx, init_duration, left=init_time, height=0.4, color='gray', alpha=0.5, label=f"{label} Init Time")

    # Set up y-axis labels - simplified to one row per file
    yticks = list(range(len(events_dict)))
    yticklabels = labels if labels else events_dict.keys()
    
    ax.set_yticks(yticks)
    ax.set_yticklabels(yticklabels)
    ax.set_xlabel('Time (s)')
    # ax.set_title('Timeline')
    ax.grid(True, alpha=0.3, axis='x')
    ax.set_ylim(-0.3, len(events_dict)-0.7)
    ax.set_xlim(left=0,right=25)

    plt.tight_layout()
    
    if output:
        plt.savefig(output, dpi=300, bbox_inches='tight')
        plt.savefig(output.replace("pdf","png"), dpi=300, bbox_inches='tight')
        print(f"Timeline plot saved to: {output}")
    else:
        plt.show()

def main():
    parser = argparse.ArgumentParser(description='Create timeline visualization from log files')
    parser.add_argument('base_dir', nargs='?', default='.', 
                       help='Base directory to search for log files (default: current directory)')
    parser.add_argument('-o', '--output', help='Output file path for the plot (optional)',default="all_timelines.pdf")
    
    args = parser.parse_args()
    
    # Find log files
    log_files = find_log_files(args.base_dir)
    
    if not log_files:
        print(f"No log files (nekrs_0.out or train_0.out) found in {args.base_dir}")
        return
    
    print(f"Found log files: {list(log_files.keys())}")
    
    # Parse the log files
    events_dict = {}
    init_timestamps = {}
    for file_type, file_path in log_files.items():

        events_dict[file_type] = {"timestep": [], "data_transport": []}
        print(f"Parsing {file_type} log: {file_path}")
        
        # Use the appropriate parser based on file type
        if file_type == 'Simulation':
            events = parse_nekrs_log(file_path)
        elif file_type == 'Training':
            events = parse_training_log(file_path)
        elif file_type == 'Inference':
            events = parse_inference_log(file_path)
        else:
            print(f"Unknown file type: {file_type}")
            continue
        
        if file_type in ["Training", "Inference"]:
            with open(file_path, 'r') as f:
                for line in f.readlines():
                    timestamp = parse_timestamp(line)
                    if timestamp:
                        init_timestamps[file_type] = timestamp
                        break
        if events:
            events_dict[file_type]["timestep"] = [e for e in events if e['type'] == 'timestep']
            events_dict[file_type]["data_transport"] = [e for e in events if e['type'] == 'data_transport']
            print(f"Parsed {len(events)} events")
        else:
            print(f"No events found in {file_path}")

    if not events_dict:
        print("No events found in any log files!")
        return

    plot_timelines(events_dict, init_timestamps, output=args.output)

if __name__ == '__main__':
    main()
